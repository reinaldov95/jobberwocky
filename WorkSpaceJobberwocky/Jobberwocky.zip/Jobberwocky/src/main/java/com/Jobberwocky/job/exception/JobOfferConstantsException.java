package com.Jobberwocky.job.exception;

import java.io.FileReader;
import java.util.Properties;

public class JobOfferConstantsException {
	
	public static final String NOT_FOUND_DATA = "NOT_FOUND_DATA";
	public static final String NOT_HAVE_OFFERS = "NOT_HAVE_OFFERS";	
	public static final String CANT_CREATE = "CANT_CREATE";	

}
